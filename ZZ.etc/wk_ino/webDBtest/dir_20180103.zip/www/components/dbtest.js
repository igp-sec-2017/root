/**
 * Web SQL Database access
 * Created 2017/11/12@m.inoha 
 */
 
    // DB初期設定
    document.addEventListener("deviceready", onDeviceReady, false);

    function onDeviceReady() {
        window.alert("Create a database and display the content");
    }

    // DBデータ初期化
    function executeInitQuery(tx) {
        var upd = getNow('2'); // 更新日
        var ver = "ver1.0"; // 初期バージョン
        tx.executeSql('DROP TABLE IF EXISTS VersionTable');
        tx.executeSql('CREATE TABLE IF NOT EXISTS VersionTable (id unique, version, upddate)');
        tx.executeSql('INSERT INTO VersionTable (id, version, upddate) VALUES (?,?,?)',[1,ver,upd]);
        window.alert('初期化しました。\n日付：' + upd + '\nバージョン：' + ver);
    }

    // selectSQL（バージョン情報取得1レコード）
    function queryDB(tx) {
        tx.executeSql('SELECT * FROM VersionTable ORDER BY id desc limit 1', [], querySuccess, errorCB);
    }

    // selectSQL（バージョン情報取得全レコード）
    function queryAllSelectDB(tx) {
        tx.executeSql('SELECT * FROM VersionTable ORDER BY id desc', [], querySuccess, errorCB);
    }

    // updateSQL(バージョン情報を追加)
    function queryUpdDB(tx) {
        var ver = "ver2.0." + getNow('1');
        var upd = getNow('2');
        tx.executeSql('INSERT INTO VersionTable (id, version, upddate) VALUES ((SELECT MAX(id)+1 FROM VersionTable),?,?)',[ver,upd]);
        window.alert('バージョン情報を更新しました。取得バージョン' + ver);
    }

    // データ取得結果
    function querySuccess(tx, results) {
        var res = "";
        var len = results.rows.length;
        for (var i=0; i<len; i++){
            res += "ID：" + results.rows.item(i).id + "<br/>バージョン：" + results.rows.item(i).version + "<br/>更新日：" + results.rows.item(i).upddate+"<br/><br/>";
        }
        outPut(res);
    }

    // SQL Error
    function errorCB(err) {
        console.log("Error occured while executing SQL: "+err.code);
    }

    // Execute DB Initialize ボタンのアクション
    function initializeDB(){
        var db = window.openDatabase("Database", "1.0", "WebDB", 200000);
        db.transaction(executeInitQuery, errorCB, getVersion);
        //window.alert(res);
    }

    // Get Version ボタンのアクション
    function getVersion() {
        var db = window.openDatabase("Database", "1.0", "WebDB", 200000);
        db.transaction(queryDB, errorCB);
    }
   
    // All Select Version ボタンのアクション
    function allSelectVersion() {
        var db = window.openDatabase("Database", "1.0", "WebDB", 200000);
        db.transaction(queryAllSelectDB, errorCB);
    }
   
    // Update Version ボタンのアクション
    function updateVersion() {
        var db = window.openDatabase("Database", "1.0", "WebDB", 200000);
        db.transaction(queryUpdDB, errorCB);
    }
   
    // HTMLへ結果を表示（仮）
    function outPut(str){
        document.getElementById('result').innerHTML = str;
    }
    
    function phpCpr() {
        var str ='';
        // Ajaxで～.phpを利用してDBにアクセス
        $.ajax({
            type: 'POST',
            scriptCharset: 'utf-8',
            dataType: 'json',
            url: 'http://igp-sec-2017.sakura.ne.jp/index.php'
       }).done(function(data){
            console.log("完了！");
            console.log(data);
            for (var i = 0; i < data.length; i++){
                str = str + 'バージョン：ver' + data[i]["version"] + '<br>';
                str = str + '更新日：' + data[i]["upddate"] + '<br><br>';
            }
            document.getElementById('result').innerHTML = str;
        }).fail(function(data){
           alert('error!!!');
           console.log("error");
           console.log(data);
       });


    }
    