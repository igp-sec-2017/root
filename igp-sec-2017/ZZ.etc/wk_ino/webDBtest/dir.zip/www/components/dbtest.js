/**
 * Web SQL Database access
 * Created 2017/11/12@m.inoha 
 */
 
    // DB初期設定
    document.addEventListener("deviceready", onDeviceReady, false);

    function onDeviceReady() {
        window.alert("Create a database and display the content");
    }

    // DBデータ初期化
    function executeInitQuery(tx) {
        var upd = getNow('2'); // 更新日
        window.alert(upd);
        var ver = "ver1.0"; // 初期バージョン
        tx.executeSql('DROP TABLE IF EXISTS VersionTable');
        tx.executeSql('CREATE TABLE IF NOT EXISTS VersionTable (id unique, version, upddate)');
        tx.executeSql('INSERT INTO VersionTable (id, version, upddate) VALUES (?,?,?)',[1,ver,upd]);

    }

    // selectSQL（バージョン情報取得）
    function queryDB(tx) {
        tx.executeSql('SELECT * FROM VersionTable ORDER BY id desc', [], querySuccess, errorCB);
    }

    // updateSQL(バージョン情報を追加)
    function queryUpdDB(tx) {
        var ver = "ver2.0." + getNow('1');
        var upd = getNow('2');
        tx.executeSql('INSERT INTO VersionTable (id, version, upddate) VALUES ((SELECT MAX(id)+1 FROM VersionTable),?,?)',[ver,upd]);
    }

    // データ取得結果
    function querySuccess(tx, results) {
        var res = "";
        var len = results.rows.length;
        for (var i=0; i<len; i++){
            res += "ID：" + results.rows.item(i).id + "<br/>バージョン：" + results.rows.item(i).version + "<br/>更新日：" + results.rows.item(i).upddate+"<br/><br/>";
        }
        outPut(res);
    }

    // SQL Error
    function errorCB(err) {
        console.log("Error occured while executing SQL: "+err.code);
    }

    // Execute DB Initialize ボタンのアクション
    function initializeDB(){
        var db = window.openDatabase("Database", "1.0", "WebDB", 200000);
        db.transaction(executeInitQuery, errorCB, selectVersion);
        //window.alert(res);
    }

    // Get Version ボタンのアクション
    function selectVersion() {
        var db = window.openDatabase("Database", "1.0", "WebDB", 200000);
        db.transaction(queryDB, errorCB);
    }
   
    // Update Version ボタンのアクション
    function updateVersion() {
        var db = window.openDatabase("Database", "1.0", "WebDB", 200000);
        db.transaction(queryUpdDB, errorCB, selectVersion);
    }
   
    // HTMLへ結果を表示（仮）
    function outPut(str){
        document.getElementById('result').innerHTML = str;
    }